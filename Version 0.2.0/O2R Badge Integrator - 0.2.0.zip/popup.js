var ProgressBar = require('progressbar.js')
var line = new ProgressBar.Line('#container');

	 window.onload = function onLoad() {
		var circle = new ProgressBar.Circle('#progress', {
			color: '#FCB03C',
			duration: 3000,
			easing: 'easeInOut'
		});

		circle.animate(1);
	};
 